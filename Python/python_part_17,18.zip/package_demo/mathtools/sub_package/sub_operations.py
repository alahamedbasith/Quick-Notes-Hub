import random

def random_number():
    return random.randint(1, 100)

