import math as m 

def add_mul(a, b):
    return a + b, a * b

def square_cube(x):
    return x ** 2, x ** 3

def sqrt_cube_root(x):
    return m.sqrt(x), m.cbrt(x)