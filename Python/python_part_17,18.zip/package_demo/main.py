from mathtools.operations import add_mul, square_cube, sqrt_cube_root
#from mathtools.sub_package.sub_operations import random_numbers
import mathtools.sub_package.sub_operations as so
# a = int(input("Enter first number: "))
# b = int(input("Enter second number: "))

import demo_namespace.demo as d
import demo_namespace_01.demo as d1

# print(add_mul(a,b))


# print(square_cube(a))
# print(sqrt_cube_root(a))

# for _ in range(10):
#     print(so.random_number())

print(d1.add(10, 20))
